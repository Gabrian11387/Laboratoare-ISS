package bugs.Controller;

import bugs.Domain.Angajat;
import bugs.Domain.Bug;
import bugs.Domain.Status;
import bugs.Service.Service;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class TesterController {
    Stage prevStage;
    Service service;
    Angajat tester;

    @FXML
    public TextField denumireTextField;
    @FXML
    public TextArea descriereTextArea;

    public void setService(Service service, Angajat tester) {
        this.service = service;
        this.tester = tester;
    }

    public void setStage(Stage stage) {
        this.prevStage = stage;
    }

    public void handleLogOutButton(javafx.event.ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Sigur vrei sa te deloghezi?");
        alert.setContentText("Confirm");

        alert.showAndWait().ifPresent(response -> {
            if (response == javafx.scene.control.ButtonType.OK) {
                try {
                    service.logout(tester);
                    ((Node)(actionEvent.getSource())).getScene().getWindow().hide();
                    prevStage.show();
                    AlertMessage.showMessage(null, Alert.AlertType.INFORMATION, "Succes", "Te-ai delogat");
                } catch (Exception e) {
                    System.out.println("Logout error " + e);
                }
            }
        });
    }

}
