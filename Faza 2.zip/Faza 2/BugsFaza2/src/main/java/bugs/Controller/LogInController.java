package bugs.Controller;

import bugs.Domain.Angajat;
import bugs.Domain.Role;
import bugs.Service.Service;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LogInController {

    Service service;
    Stage stage;

    public PasswordField passwordTextField;
    public TextField usernameTextField;

    public void setService(Service service) {
        this.service = service;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void handleLogInButton() throws IOException {
        if (usernameTextField.getText().isEmpty() || passwordTextField.getText().isEmpty()) {
            AlertMessage.showErrorMessage(null, "Invalid username or password");
            return;
        }

        String regexDev = "^d_.*";
        String regexTester = "^t_.*";

        if (usernameTextField.getText().trim().matches(regexDev)) {
            Angajat dev = new Angajat(usernameTextField.getText().trim(), passwordTextField.getText().trim(), Role.developer);
            try {
                service.login(dev);
                AlertMessage.showMessage(null, Alert.AlertType.INFORMATION, "Succes", "Te-ai logat");
            } catch (Exception e) {
                AlertMessage.showErrorMessage(null, e.getMessage());
                return;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("dev-view.fxml"));
            Parent devRoot = loader.load();

            Stage devStage = new Stage();
            devStage.setTitle("Welcome back " + usernameTextField.getText().trim() + "!");
            devStage.setScene(new Scene(devRoot));

            DeveloperController developerController = loader.getController();
            developerController.setService(service, dev);
            developerController.setStage(stage);

            stage.hide();
            devStage.show();

            usernameTextField.clear();
            passwordTextField.clear();

        } else if (usernameTextField.getText().trim().matches(regexTester)) {
            Angajat tester = new Angajat(usernameTextField.getText().trim(), passwordTextField.getText().trim(), Role.tester);
            try {
                service.login(tester);
                AlertMessage.showMessage(null, Alert.AlertType.INFORMATION, "Succes", "Te-ai logat");
            } catch (Exception e) {
                AlertMessage.showErrorMessage(null, e.getMessage());
                return;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("tester-view.fxml"));
            Parent testerRoot = loader.load();

            Stage testerStage = new Stage();
            testerStage.setTitle("Welcome back " + usernameTextField.getText().trim() + "!");
            testerStage.setScene(new Scene(testerRoot));

            TesterController testerController = loader.getController();
            testerController.setService(service, tester);
            testerController.setStage(stage);

            stage.hide();
            testerStage.show();

            usernameTextField.clear();
            passwordTextField.clear();

        } else {
            AlertMessage.showErrorMessage(null, "Invalid username or password");
        }
    }
    
    public void handleSignUpHyperlink() {
        // nimic
    }
}
