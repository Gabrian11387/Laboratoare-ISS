package bugs.Controller;

import bugs.Domain.Angajat;
import bugs.Domain.Bug;
import bugs.Domain.Status;
import bugs.Service.Event.ChangeEvent;
import bugs.Service.Event.ChangeEventType;
import bugs.Service.Observer.IObserver;
import bugs.Service.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.StreamSupport;


public class DeveloperController{
    Stage prevStage;
    Service service;
    Angajat dev;

    ObservableList<Bug> modelBugs = FXCollections.observableArrayList();

    @FXML
    public TableView<Bug> bugsTableView;
    @FXML
    public TableColumn<Bug, String> denumireTableColumn;
    @FXML
    public TableColumn<Bug, String> descriereTableColumn;
    @FXML
    public TableColumn<Bug, String> statusTableColumn;
    @FXML
    public ComboBox<String> statusComboBox;
    @FXML
    public TextField denumireFilterTextField;
    @FXML
    public TextField descriereFilterTextField;

    public void setService(Service service, Angajat dev) {
        this.service = service;
        this.dev = dev;
        //this.service.addObserver(this);
        //initModel();
        //initComboBox();
    }

    public void setStage(Stage stage) {
        this.prevStage = stage;
    }

    @FXML
    public void initialize() {
        denumireTableColumn.setCellValueFactory(new PropertyValueFactory<>("denumire"));
        descriereTableColumn.setCellValueFactory(new PropertyValueFactory<>("descriere"));
        statusTableColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        bugsTableView.setItems(modelBugs);
    }

//    public void initModel() {
//        Iterable<Bug> allBugs = service.findAllBugs();
//        List<Bug> bugList = StreamSupport.stream(allBugs.spliterator(), false)
//                .toList();
//        modelBugs.setAll(bugList);
//    }


    public void handleLogOutButton(javafx.event.ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Sigur vrei sa te deloghezi?");
        alert.setContentText("Confirm");

        alert.showAndWait().ifPresent(response -> {
            if (response == javafx.scene.control.ButtonType.OK) {
                try {
                    service.logout(dev);
                    //service.removeObserver(this);
                    ((Node)(actionEvent.getSource())).getScene().getWindow().hide();
                    prevStage.show();
                    AlertMessage.showMessage(null, Alert.AlertType.INFORMATION, "Succes", "Te-ai delogat");
                } catch (Exception e) {
                    System.out.println("Logout error " + e);
                }
            }
        });
    }

}
