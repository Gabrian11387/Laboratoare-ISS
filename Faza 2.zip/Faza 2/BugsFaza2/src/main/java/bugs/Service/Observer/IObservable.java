package bugs.Service.Observer;

import bugs.Domain.Bug;
import bugs.Service.Event.ChangeEvent;

public interface IObservable {
    // void addObserver(IObserver<ChangeEvent<Bug>> observer);
    // void removeObserver(IObserver<ChangeEvent<Bug>> observer);
    // void notifyObservers(ChangeEvent<Bug> t);
}
