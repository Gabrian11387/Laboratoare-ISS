package bugs.Service;

import bugs.Domain.Angajat;
import bugs.Domain.Bug;
import bugs.Repository.Interface.IRepoAngajat;
import bugs.Repository.Interface.IRepoBug;
import bugs.Service.Event.ChangeEvent;
import bugs.Service.Event.ChangeEventType;
import bugs.Service.Observer.IObservable;
import bugs.Service.Observer.IObserver;

import java.util.*;

import static bugs.Service.Password.Password.verifyPassword;

public class Service implements IObservable {
    private final IRepoAngajat repoAngajat;
    private final Map<String, String> loggedUsers;

    public Service(IRepoAngajat repoAngajat) {
        this.repoAngajat = repoAngajat;
        this.loggedUsers = new HashMap<>();
    }

    public void login(Angajat angajat) throws Exception {
        Optional<Angajat> user = repoAngajat.findOneByUsername(angajat.getUsername());
        if (user.isEmpty()) {
            throw new Exception("Authentication failed!");
        } else {
            if (!verifyPassword(angajat.getPassword(), user.get().getPassword())) {
                throw new Exception("Invalid username or password!");
            }
            if (loggedUsers.get(user.get().getUsername()) != null) {
                throw new Exception("User already logged in!");
            }
            loggedUsers.put(user.get().getUsername(), user.get().getRole().toString());
        }
    }

    public void logout(Angajat angajat) throws Exception{
        var value = loggedUsers.remove(angajat.getUsername());
        if (value == null)
            throw new Exception("User " + angajat.getUsername() + " is not logged in.");
    }

}
