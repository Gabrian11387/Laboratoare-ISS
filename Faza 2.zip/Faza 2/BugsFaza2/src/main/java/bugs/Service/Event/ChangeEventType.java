package bugs.Service.Event;

public enum ChangeEventType {
    add, delete, update
}
