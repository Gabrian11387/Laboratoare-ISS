package bugs.Domain;

import jakarta.persistence.*;
import jakarta.persistence.Entity;

import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "bug")
public class Bug implements bugs.Domain.Entity<UUID> {
    private UUID id;
    private String denumire, descriere;
    private Status status;

    public Bug() {
        id = UUID.randomUUID();
        denumire = descriere = "default";
        status = Status.defaultStatus;
    }

    public Bug(String denumire, String descriere, Status status) {
        this.id = UUID.randomUUID();
        this.denumire = denumire;
        this.descriere = descriere;
        this.status = status;
    }

    @Override
    public void setId(UUID uuid) {
        this.id = uuid;
    }

    @Id
    @Column(name = "bug_id")
    @GeneratedValue(generator = "UUID")
    @Override
    public UUID getId() {
        return this.id;
    }

    @Column(name = "denumire")
    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    @Column(name = "descriere")
    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Bug{" +
                "id=" + id +
                ", denumire='" + denumire + '\'' +
                ", descriere='" + descriere + '\'' +
                ", status=" + status +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Bug bug)) return false;
        return Objects.equals(id, bug.id) && Objects.equals(denumire, bug.denumire) && Objects.equals(descriere, bug.descriere) && status == bug.status;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, denumire, descriere, status);
    }
}
