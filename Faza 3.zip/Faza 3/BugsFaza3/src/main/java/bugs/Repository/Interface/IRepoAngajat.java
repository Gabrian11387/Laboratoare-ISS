package bugs.Repository.Interface;

import bugs.Domain.Angajat;

import java.util.Optional;
import java.util.UUID;

public interface IRepoAngajat extends IRepository<UUID, Angajat> {
    Optional<Angajat> findOneByUsername(String username);
}
