package bugs.Repository.DBRepos;

import bugs.Domain.Bug;
import bugs.Domain.Status;
import bugs.Repository.Interface.IRepoBug;
import bugs.Repository.Utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Optional;
import java.util.UUID;

public class BugRepo implements IRepoBug {
    @Override
    public Optional<Bug> findOne(UUID uuid) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.createSelectionQuery("from Bug where id=:idM ", Bug.class)
                    .setParameter("idM", uuid)
                    .getSingleResultOrNull());
        }
    }

    @Override
    public Iterable<Bug> findAll() {
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.createQuery("from Bug ", Bug.class).getResultList();
        }
    }

    @Override
    public Optional<Bug> save(Bug entity) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(entity);
            tx.commit();
            if (entity.getId() != null) {
                return Optional.empty();
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
        }
        return Optional.of(entity);
    }

    @Override
    public Optional<Bug> delete(UUID uuid) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Bug bug = session.createQuery("from Bug where id=?1", Bug.class)
                    .setParameter(1, uuid)
                    .uniqueResult();
            if (bug != null) {
                session.remove(bug);
                tx.commit();
                return Optional.of(bug);
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
        }
        return Optional.empty();
    }

    @Override
    public Optional<Bug> update(Bug entity) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(entity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            return Optional.of(entity);
        }
        return Optional.empty();
    }

    @Override
    public Iterable<Bug> filterBugs(String denumire, String descriere, String status) {
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {

            Status statusEnum = null;

            StringBuilder hql = new StringBuilder("from Bug where 1=1 ");
            if (denumire != null && !denumire.isEmpty()) {
                hql.append("and denumire like :denumire ");
            }
            if (descriere != null && !descriere.isEmpty()) {
                hql.append("and descriere like :descriere ");
            }
            if (status != null && !status.isEmpty()) {
                statusEnum = Status.valueOf(status);
                hql.append("and status like :status ");
            }

            var query = session.createQuery(hql.toString(), Bug.class);

            if (denumire != null && !denumire.isEmpty()) {
                query.setParameter("denumire", "%" + denumire + "%");
            }
            if (descriere != null && !descriere.isEmpty()) {
                query.setParameter("descriere", "%" + descriere + "%");
            }
            if (status != null && !status.isEmpty()) {
                query.setParameter("status", statusEnum);
            }
            return query.getResultList();
        }
    }
}
