package bugs.Repository.DBRepos;

import bugs.Domain.Angajat;
import bugs.Repository.Interface.IRepoAngajat;
import bugs.Repository.Utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Optional;
import java.util.UUID;

public class AngajatRepo implements IRepoAngajat {
    @Override
    public Optional<Angajat> findOne(UUID uuid) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.createSelectionQuery("from Angajat where id=:idM ", Angajat.class)
                    .setParameter("idM", uuid)
                    .getSingleResultOrNull());
        }
    }

    @Override
    public Iterable<Angajat> findAll() {
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.createQuery("from Angajat ", Angajat.class).getResultList();
        }
    }

    @Override
    public Optional<Angajat> save(Angajat entity) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(entity);
            tx.commit();
            if (entity.getId() != null) {
                return Optional.of(entity);
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
        }
        return Optional.empty();
    }

    @Override
    public Optional<Angajat> delete(UUID uuid) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Angajat angajat = session.createQuery("from Angajat where id=?1", Angajat.class)
                    .setParameter(1, uuid)
                    .uniqueResult();
            if (angajat != null) {
                session.remove(angajat);
                tx.commit();
                return Optional.of(angajat);
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
        }
        return Optional.empty();
    }

    @Override
    public Optional<Angajat> update(Angajat entity) {
        Transaction tx = null;
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(entity);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            return Optional.of(entity);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Angajat> findOneByUsername(String username) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.createSelectionQuery("from Angajat where username=:usernameM ", Angajat.class)
                    .setParameter("usernameM", username)
                    .getSingleResultOrNull());
        }
    }
}
