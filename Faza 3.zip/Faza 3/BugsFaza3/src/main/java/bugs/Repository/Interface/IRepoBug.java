package bugs.Repository.Interface;

import bugs.Domain.Bug;

import java.util.UUID;

public interface IRepoBug extends IRepository<UUID, Bug> {
    Iterable<Bug> filterBugs(String denumire, String descriere, String status);
}
