package bugs.Domain;

import jakarta.persistence.*;
import jakarta.persistence.Entity;

import java.util.Objects;
import java.util.UUID;

@Entity
@Table (name = "angajat")
public class Angajat implements bugs.Domain.Entity<UUID> {
    private UUID id;
    private String nume, prenume, username, password;
    private Role role;

    public Angajat() {
        id = UUID.randomUUID();
        nume = prenume = username = password = "default";
        role = Role.defaultRole;
    }

    public Angajat(String nume, String prenume, String username, String password, Role role) {
        this.id = UUID.randomUUID();
        this.nume = nume;
        this.prenume = prenume;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public Angajat(String username, String password, Role role) {
        this.id = UUID.randomUUID();
        this.nume = "";
        this.prenume = "";
        this.username = username;
        this.password = password;
        this.role = role;
    }

    @Id
    @Column(name = "angajat_id")
    @GeneratedValue(generator = "UUID")
    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public void setId(UUID uuid) {
        this.id = uuid;
    }

    @Column(name = "nume")
    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    @Column(name = "prenume")
    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    @Column(name = "username")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name = "password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Enumerated(EnumType.STRING)
    @Column(name = "rol")
    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Angajat angajat)) return false;
        return Objects.equals(id, angajat.id) && Objects.equals(nume, angajat.nume) && Objects.equals(prenume, angajat.prenume) && Objects.equals(username, angajat.username) && Objects.equals(password, angajat.password) && role == angajat.role;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nume, prenume, username, password, role);
    }

    @Override
    public String toString() {
        return "Angajat{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", role=" + role +
                '}';
    }
}
