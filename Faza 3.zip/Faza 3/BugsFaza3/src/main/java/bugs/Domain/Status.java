package bugs.Domain;

public enum Status {
    active, working, defaultStatus
}
