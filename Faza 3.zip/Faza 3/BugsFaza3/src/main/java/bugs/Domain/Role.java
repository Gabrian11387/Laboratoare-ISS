package bugs.Domain;

public enum Role {
    tester, developer, defaultRole
}
