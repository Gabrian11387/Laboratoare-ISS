package bugs.Service.Password;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Password {
    public static boolean verifyPassword(String inputPassword, String storedHash) {
        return Objects.equals(inputPassword, storedHash);
    }

}
