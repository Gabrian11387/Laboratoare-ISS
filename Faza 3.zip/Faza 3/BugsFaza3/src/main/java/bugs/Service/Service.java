package bugs.Service;

import bugs.Domain.Angajat;
import bugs.Domain.Bug;
import bugs.Repository.Interface.IRepoAngajat;
import bugs.Repository.Interface.IRepoBug;
import bugs.Service.Event.ChangeEvent;
import bugs.Service.Event.ChangeEventType;
import bugs.Service.Observer.IObservable;
import bugs.Service.Observer.IObserver;

import java.util.*;

import static bugs.Service.Password.Password.verifyPassword;

public class Service implements IObservable {
    private final IRepoAngajat repoAngajat;
    private final IRepoBug repoBug;
    private final Map<String, String> loggedUsers;

    public Service(IRepoAngajat repoAngajat, IRepoBug repoBug) {
        this.repoAngajat = repoAngajat;
        this.repoBug = repoBug;
        this.loggedUsers = new HashMap<>();
    }

    public void login(Angajat angajat) throws Exception {
        Optional<Angajat> user = repoAngajat.findOneByUsername(angajat.getUsername());
        if (user.isEmpty()) {
            throw new Exception("Authentication failed!");
        } else {
            if (!verifyPassword(angajat.getPassword(), user.get().getPassword())) {
                throw new Exception("Invalid username or password!");
            }
            if (loggedUsers.get(user.get().getUsername()) != null) {
                throw new Exception("User already logged in!");
            }
            loggedUsers.put(user.get().getUsername(), user.get().getRole().toString());
        }
    }

    public void logout(Angajat angajat) throws Exception{
        var value = loggedUsers.remove(angajat.getUsername());
        if (value == null)
            throw new Exception("User " + angajat.getUsername() + " is not logged in.");
    }

    public Iterable<Bug> findAllBugs() {
        return repoBug.findAll();
    }

    public void saveBug(Bug bug) {
        String error = "";
        if (bug.getDenumire() == null || bug.getDenumire().isEmpty()) {
            error += "Denumire invalida!\n";
        }
        if (bug.getDescriere() == null || bug.getDescriere().isEmpty()) {
            error += "Descriere invalida!\n";
        }
        if (!error.isEmpty()) {
            throw new IllegalArgumentException(error);
        }
        var savedBug = repoBug.save(bug);
        if (savedBug.isEmpty()) {
            notifyObservers(new ChangeEvent<>(ChangeEventType.add, bug));
        }
    }

    public void updateBug(Bug bug) {
        var updatedBug = repoBug.update(bug);
        if (updatedBug.isEmpty()) {
            notifyObservers(new ChangeEvent<>(ChangeEventType.update, bug));
        }
    }

    public void deleteBug(Bug bug) {
        var deletedBug = repoBug.delete(bug.getId());
        if (deletedBug.isPresent()) {
            notifyObservers(new ChangeEvent<>(ChangeEventType.delete, bug));
        }
    }

    public Iterable<Bug> filterBugs(String denumire, String descriere, String status) {
        return repoBug.filterBugs(denumire, descriere, status);
    }

    private final List<IObserver<ChangeEvent<Bug>>> observerList = new ArrayList<>();
    public void addObserver(IObserver<ChangeEvent<Bug>> observer) {
        observerList.add(observer);
    }
    public void removeObserver(IObserver<ChangeEvent<Bug>> observer) {
        observerList.remove(observer);
    }
    public void notifyObservers(ChangeEvent<Bug> e) {
        observerList.forEach(x -> x.update(e));
    }
}
