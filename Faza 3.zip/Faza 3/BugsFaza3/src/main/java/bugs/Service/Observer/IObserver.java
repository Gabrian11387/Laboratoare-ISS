package bugs.Service.Observer;

import bugs.Service.Event.IEvent;

public interface IObserver<E extends IEvent> {
    void update(E e);
}
