package bugs.Service.Event;

public interface IEvent {
}
