package bugs.Service.Event;

public class ChangeEvent<ID> implements IEvent{
    private final ChangeEventType type;
    private final ID data;
    private ID oldData;
    public ChangeEvent(ChangeEventType type, ID data) {
        this.type = type;
        this.data = data;
    }
    public ChangeEvent(ChangeEventType type, ID data, ID oldData) {
        this.type = type;
        this.data = data;
        this.oldData = oldData;
    }

    public ChangeEventType getType() {
        return type;
    }

    public ID getData() {
        return data;
    }

    public ID getOldData() {
        return oldData;
    }
}
