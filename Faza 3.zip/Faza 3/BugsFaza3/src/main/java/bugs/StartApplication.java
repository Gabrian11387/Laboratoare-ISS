package bugs;

import bugs.Controller.LogInController;
import bugs.Repository.DBRepos.AngajatRepo;
import bugs.Repository.DBRepos.BugRepo;
import bugs.Repository.Interface.IRepoAngajat;
import bugs.Repository.Interface.IRepoBug;
import bugs.Service.Service;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class StartApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        IRepoAngajat repoAngajat = new AngajatRepo();
        IRepoBug repoBug = new BugRepo();
        Service service = new Service(repoAngajat, repoBug);

        createWindow("login-view.fxml", "Login!", service);
        createWindow("login-view.fxml", "Login!", service);
    }

    public void createWindow(String fxml, String title, Service service) throws IOException {
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource(fxml));
        Parent loginRoot = loader.load();
        stage.setTitle(title);
        stage.setScene(new Scene(loginRoot));
        LogInController logInController = loader.getController();
        logInController.setStage(stage);
        logInController.setService(service);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}