package bugs.Controller;

import bugs.Domain.Angajat;
import bugs.Domain.Bug;
import bugs.Domain.Status;
import bugs.Service.Event.ChangeEvent;
import bugs.Service.Observer.IObserver;
import bugs.Service.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.StreamSupport;

public class DeveloperController implements IObserver<ChangeEvent<Bug>> {
    Stage prevStage;
    Service service;
    Angajat dev;

    ObservableList<Bug> modelBugs = FXCollections.observableArrayList();

    @FXML
    public TableView<Bug> bugsTableView;
    @FXML
    public TableColumn<Bug, String> denumireTableColumn;
    @FXML
    public TableColumn<Bug, String> descriereTableColumn;
    @FXML
    public TableColumn<Bug, String> statusTableColumn;
    @FXML
    public ComboBox<String> statusComboBox;
    @FXML
    public TextField denumireFilterTextField;
    @FXML
    public TextField descriereFilterTextField;
    @FXML
    public Button deleteButton;
    @FXML
    public Button workButton;

    public void setService(Service service, Angajat dev) {
        this.service = service;
        this.dev = dev;
        this.service.addObserver(this);
        initModel();
        initComboBox();
    }

    public void setStage(Stage stage) {
        this.prevStage = stage;
    }

    @FXML
    public void initialize() {
        denumireTableColumn.setCellValueFactory(new PropertyValueFactory<>("denumire"));
        descriereTableColumn.setCellValueFactory(new PropertyValueFactory<>("descriere"));
        statusTableColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        bugsTableView.setItems(modelBugs);

        bugsTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                if (newValue.getStatus() == Status.active) {
                    workButton.setVisible(true);
                    deleteButton.setVisible(false);
                } else if (newValue.getStatus() == Status.working) {
                    workButton.setVisible(false);
                    deleteButton.setVisible(true);
                } else {
                    workButton.setVisible(false);
                    deleteButton.setVisible(false);
                }
            } else {
                workButton.setVisible(false);
                deleteButton.setVisible(false);
            }
        });
    }

    public void initModel() {
        Iterable<Bug> allBugs = service.findAllBugs();
        List<Bug> bugList = StreamSupport.stream(allBugs.spliterator(), false)
                .toList();
        modelBugs.setAll(bugList);
    }

    public void initComboBox() {
        statusComboBox.getItems().addAll(
                "active",
                "working"
        );
        statusComboBox.setPromptText("Status");
    }

    public void handleApplyFiltersButton() {
        String denumire = denumireFilterTextField.getText().trim();
        String descriere = descriereFilterTextField.getText().trim();
        String status = statusComboBox.getValue();

        Iterable<Bug> filteredBugs = service.filterBugs(denumire, descriere, status);
        List<Bug> bugList = StreamSupport.stream(filteredBugs.spliterator(), false)
                .toList();
        modelBugs.setAll(bugList);

        denumireFilterTextField.clear();
        descriereFilterTextField.clear();
        statusComboBox.setValue(null);
        statusComboBox.setPromptText("Status");
    }

    public void handleDeleteButton() {
        Bug selectedBug = bugsTableView.getSelectionModel().getSelectedItem();
        if (selectedBug != null) {
            service.deleteBug(selectedBug);
            modelBugs.remove(selectedBug);
            deleteButton.setVisible(false);
        }
    }

    public void handleWorkButton() {
        Bug selectedBug = bugsTableView.getSelectionModel().getSelectedItem();
        if (selectedBug != null && selectedBug.getStatus() == Status.active) {
            selectedBug.setStatus(Status.working);
            service.updateBug(selectedBug);
            bugsTableView.refresh();
            workButton.setVisible(false);
            deleteButton.setVisible(true);
        }
    }

    public void handleLogOutButton(javafx.event.ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Sigur vrei sa te deloghezi?");
        alert.setContentText("Confirm");

        alert.showAndWait().ifPresent(response -> {
            if (response == javafx.scene.control.ButtonType.OK) {
                try {
                    service.logout(dev);
                    ((Node)(actionEvent.getSource())).getScene().getWindow().hide();
                    prevStage.show();
                    AlertMessage.showMessage(null, Alert.AlertType.INFORMATION, "Succes", "Te-ai delogat");
                } catch (Exception e) {
                    System.out.println("Logout error " + e);
                }
            }
        });
    }

    @Override
    public void update(ChangeEvent<Bug> event) {
        switch (event.getType()) {
            case add -> modelBugs.add(event.getData());
            case update -> {
                for (Bug item : bugsTableView.getItems()) {
                    if (item.getId().equals(event.getData().getId())) {
                        item.setStatus(event.getData().getStatus());
                        break;
                    }
                }
                bugsTableView.refresh();
            }
            case delete -> modelBugs.removeIf(x -> x.getId().equals(event.getData().getId()));
        }
    }
}
