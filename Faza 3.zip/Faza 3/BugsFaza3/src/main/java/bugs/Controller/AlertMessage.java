package bugs.Controller;

import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class AlertMessage {
    public static void showMessage(Stage owner, Alert.AlertType type, String header, String text){
        Alert message = new Alert(type);
        styleAlert(message, "#E8F5E9", "#4CAF50", "#4CAF50", "#333333");
        message.setHeaderText(header);
        message.setContentText(text);
        message.initOwner(owner);
        message.showAndWait();
    }

    public static void showErrorMessage(Stage owner, String text){
        Alert message = new Alert(Alert.AlertType.ERROR);
        styleAlert(message, "#FFD6D6", "#FF5A5A", "#FF5A5A", "#FF0000");
        message.initOwner(owner);
        message.setTitle("Mesaj eroare");
        message.setContentText(text);
        message.showAndWait();
    }

    private static void styleAlert(Alert alert, String backgroundColor, String borderColor, String headerColor, String textColor) {
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle(
                "-fx-background-color: " + backgroundColor + ";" +
                        "-fx-border-color: " + borderColor + ";" +
                        "-fx-border-width: 2px;");

        Label headerLabel = (Label) dialogPane.lookup(".header-panel .header");
        if (headerLabel != null) {
            headerLabel.setStyle("-fx-background-color: " + headerColor + ";");
        }

        Label contentLabel = (Label) dialogPane.lookup(".content.label");
        if (contentLabel != null) {
            contentLabel.setStyle("-fx-text-fill: " + textColor + ";");
        }
    }
}